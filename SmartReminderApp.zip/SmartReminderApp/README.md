# Smart Reminder — Android App

This is your "Smart Reminder" web app wrapped as a real Android app using
**Capacitor**, with native alarm/notification support so reminders fire with
sound even when the app is closed.

## What's in here

- `www/index.html` — your original app (untouched, plus a small native bridge hook)
- `www/native-bridge.js` — connects the app's reminder logic to Android's real
  alarm/notification system (`@capacitor/local-notifications`)
- `android/` — the full native Android Studio project
- `.github/workflows/build-apk.yml` — GitHub Actions workflow that **automatically
  builds an installable `.apk` file** every time you push to `main`/`master`,
  or whenever you trigger it manually. No Android Studio required.

## How to get your APK (no local setup needed)

1. Create a new GitHub repository (public or private, doesn't matter).
2. Push this entire folder to it:
   ```bash
   cd SmartReminderApp
   git init
   git add .
   git commit -m "Smart Reminder Android app"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. Go to your repo on GitHub → the **Actions** tab. You'll see "Build Android APK"
   running automatically (takes ~2-3 minutes).
4. When it finishes, click into that run → scroll down to **Artifacts** →
   download `smart-reminder-debug-apk` → unzip it to get `app-debug.apk`.
5. Transfer that `.apk` to your Android phone (email it to yourself, Google
   Drive, USB, etc.), tap it, allow "install from unknown sources" if prompted,
   and install.

You now have a real installable app icon on your phone — login, reminders,
and alarms work exactly as in the web version, but alarms are also scheduled
natively so they ring even if the app is in the background or closed.

## If you want to build it locally instead (Android Studio)

```bash
npm install
npx cap copy android
npx cap open android   # opens Android Studio
```
Then click Run, or Build → Build APK(s).

## Important notes

- **This is a debug build.** It's fully installable and functional, but not
  signed for the Play Store. That's fine for personal use / sideloading.
  If you eventually want to publish to the Play Store, you'll need to
  generate a release keystore and switch the workflow to `assembleRelease`
  — ask me and I'll set that up too.
- **Login/accounts**: the original app stores users in local browser storage
  (no real backend), so accounts only exist on each device. If you want
  shared accounts across devices (real backend + database), that's a
  separate project — let me know if you want that built.
- **Custom ringtones**: the reminder type ("Short Alarm" / "Continuous Alarm")
  is now mapped to native notification channels. To use a fully custom
  ringtone file, drop an `.mp3`/`.ogg` into
  `android/app/src/main/res/raw/` (e.g. `alarm_loop.mp3`) — the bridge
  already references `alarm_loop` / `alarm_short` sound names.
- On first launch, Android will prompt for notification permission — make
  sure the user taps "Allow" or alarms won't fire.
