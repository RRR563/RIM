/*
  native-bridge.js
  Connects the Smart Reminder web app to real native Android alarms
  via the Capacitor LocalNotifications plugin, so reminders fire with
  sound/vibration even when the app is closed or the phone is locked.

  Usage from app code (already a global, no import needed):
    NativeAlarms.requestPermission()
    NativeAlarms.schedule({ id, title, body, atDate, sound }) // sound = 'default' or filename in android/app/src/main/res/raw
    NativeAlarms.cancel(id)
*/
(function (global) {
  var LocalNotifications = null;
  var isNative = !!(global.Capacitor && global.Capacitor.isNativePlatform && global.Capacitor.isNativePlatform());

  function getPlugin() {
    if (LocalNotifications) return LocalNotifications;
    if (global.Capacitor && global.Capacitor.Plugins && global.Capacitor.Plugins.LocalNotifications) {
      LocalNotifications = global.Capacitor.Plugins.LocalNotifications;
    }
    return LocalNotifications;
  }

  var NativeAlarms = {
    isNative: isNative,

    requestPermission: function () {
      var plugin = getPlugin();
      if (!plugin) return Promise.resolve({ display: 'unsupported' });
      return plugin.requestPermissions();
    },

    // id: number, title/body: string, atDate: JS Date, sound: 'default' or a raw resource filename (without extension)
    schedule: function (opts) {
      var plugin = getPlugin();
      if (!plugin) {
        // Fallback for browser/dev mode: use Notification API + setTimeout (only while page is open)
        var ms = opts.atDate.getTime() - Date.now();
        if (ms > 0 && 'Notification' in global) {
          setTimeout(function () {
            if (Notification.permission === 'granted') {
              new Notification(opts.title, { body: opts.body });
            }
          }, ms);
        }
        return Promise.resolve();
      }
      return plugin.schedule({
        notifications: [
          {
            id: opts.id,
            title: opts.title,
            body: opts.body,
            schedule: { at: opts.atDate, allowWhileIdle: true },
            sound: opts.sound || 'default',
            smallIcon: 'ic_stat_icon_config_sample',
            channelId: 'reminders'
          }
        ]
      });
    },

    cancel: function (id) {
      var plugin = getPlugin();
      if (!plugin) return Promise.resolve();
      return plugin.cancel({ notifications: [{ id: id }] });
    },

    createChannel: function () {
      var plugin = getPlugin();
      if (!plugin || !plugin.createChannel) return Promise.resolve();
      return plugin.createChannel({
        id: 'reminders',
        name: 'Reminders & Alarms',
        description: 'Custom reminder alarms',
        importance: 5, // MAX importance -> heads-up + sound
        visibility: 1,
        sound: 'default',
        vibration: true
      });
    }
  };

  global.NativeAlarms = NativeAlarms;

  // Auto-init: ask permission + create channel once native platform is ready
  document.addEventListener('deviceready', function () {
    NativeAlarms.createChannel();
    NativeAlarms.requestPermission();
  });
  // Also run immediately in case deviceready already fired or running on web
  if (isNative) {
    NativeAlarms.createChannel();
    NativeAlarms.requestPermission();
  }
})(window);
